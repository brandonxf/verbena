"use client"

import useSWR from "swr"
import { useState } from "react"
import { Calendar, FileText } from "lucide-react"
import { formatCOP } from "@/lib/types"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

const COLORS = [
  "hsl(140 55% 35%)",
  "hsl(350 70% 45%)",
  "hsl(45 90% 50%)",
  "hsl(0 0% 18%)",
  "hsl(28 80% 52%)",
  "hsl(200 50% 45%)",
]

export default function ReportesPage() {
  const [date, setDate] = useState(new Date().toISOString().split("T")[0])
  const { data } = useSWR(`/api/reports?date=${date}`, fetcher)

  return (
    <div className="p-4 md:p-6 lg:p-8">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Reportes</h1>
          <p className="text-sm text-muted-foreground">
            Reporte diario de ventas
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="rounded-lg border border-input bg-background px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
      </div>

      {!data ? (
        <div className="flex items-center justify-center p-16">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
        </div>
      ) : (
        <>
          {/* Summary cards */}
          <div className="mb-6 grid gap-4 grid-cols-2 lg:grid-cols-4">
            <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
              <p className="text-xs text-muted-foreground">Total Pedidos</p>
              <p className="text-2xl font-bold text-foreground">
                {data.summary?.total_orders || 0}
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
              <p className="text-xs text-muted-foreground">Ingresos</p>
              <p className="text-2xl font-bold text-primary">
                {formatCOP(Number(data.summary?.total_revenue || 0))}
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
              <p className="text-xs text-muted-foreground">Ticket Promedio</p>
              <p className="text-2xl font-bold text-foreground">
                {formatCOP(Number(data.summary?.avg_ticket || 0))}
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-4 shadow-sm">
              <p className="text-xs text-muted-foreground">Cancelados</p>
              <p className="text-2xl font-bold text-destructive">
                {data.summary?.cancelled_count || 0}
              </p>
            </div>
          </div>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Hourly breakdown */}
            <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
              <h2 className="mb-4 flex items-center gap-2 text-sm font-semibold text-foreground">
                <FileText className="h-4 w-4 text-primary" />
                Ventas por Hora
              </h2>
              {data.hourly && data.hourly.length > 0 ? (
                <ResponsiveContainer width="100%" height={250}>
                  <BarChart
                    data={data.hourly.map(
                      (h: {
                        hour: number
                        orders: number
                        revenue: number
                      }) => ({
                        hora: `${String(h.hour).padStart(2, "0")}:00`,
                        ingresos: Number(h.revenue),
                        pedidos: Number(h.orders),
                      })
                    )}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      stroke="hsl(40 12% 86%)"
                    />
                    <XAxis
                      dataKey="hora"
                      tick={{ fontSize: 12, fill: "hsl(0 0% 40%)" }}
                    />
                    <YAxis
                      tick={{ fontSize: 12, fill: "hsl(0 0% 40%)" }}
                    />
                    <Tooltip
                      formatter={(value: number) => formatCOP(value)}
                      contentStyle={{
                        borderRadius: "8px",
                        border: "1px solid hsl(40 12% 86%)",
                        fontSize: "12px",
                      }}
                    />
                    <Bar
                      dataKey="ingresos"
                      fill="hsl(140 55% 35%)"
                      radius={[4, 4, 0, 0]}
                      name="Ingresos"
                    />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <p className="py-16 text-center text-sm text-muted-foreground">
                  Sin datos para esta fecha
                </p>
              )}
            </div>

            {/* Product breakdown pie chart */}
            <div className="rounded-xl border border-border bg-card p-5 shadow-sm">
              <h2 className="mb-4 text-sm font-semibold text-foreground">
                Ventas por Producto
              </h2>
              {data.products && data.products.length > 0 ? (
                <div>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={data.products.map(
                          (
                            p: {
                              product_name: string
                              total_quantity: number
                              total_sales: number
                            },
                            i: number
                          ) => ({
                            name: p.product_name,
                            value: Number(p.total_sales),
                            fill: COLORS[i % COLORS.length],
                          })
                        )}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        dataKey="value"
                        label={({ name, percent }) =>
                          `${name} ${(percent * 100).toFixed(0)}%`
                        }
                        labelLine
                      >
                        {data.products.map(
                          (
                            _: {
                              product_name: string
                              total_quantity: number
                              total_sales: number
                            },
                            index: number
                          ) => (
                            <Cell
                              key={`cell-${index}`}
                              fill={COLORS[index % COLORS.length]}
                            />
                          )
                        )}
                      </Pie>
                      <Tooltip
                        formatter={(value: number) => formatCOP(value)}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="mt-4 space-y-2">
                    {data.products.map(
                      (
                        p: {
                          product_name: string
                          total_quantity: number
                          total_sales: number
                        },
                        i: number
                      ) => (
                        <div
                          key={p.product_name}
                          className="flex items-center justify-between text-sm"
                        >
                          <div className="flex items-center gap-2">
                            <div
                              className="h-3 w-3 rounded-full"
                              style={{
                                backgroundColor: COLORS[i % COLORS.length],
                              }}
                            />
                            <span className="text-foreground">
                              {p.product_name}
                            </span>
                            <span className="text-muted-foreground">
                              ({p.total_quantity} uds)
                            </span>
                          </div>
                          <span className="font-medium text-foreground">
                            {formatCOP(Number(p.total_sales))}
                          </span>
                        </div>
                      )
                    )}
                  </div>
                </div>
              ) : (
                <p className="py-16 text-center text-sm text-muted-foreground">
                  Sin datos para esta fecha
                </p>
              )}
            </div>

            {/* Toppings sold */}
            <div className="rounded-xl border border-border bg-card p-5 shadow-sm lg:col-span-2">
              <h2 className="mb-4 text-sm font-semibold text-foreground">
                Toppings Vendidos
              </h2>
              {data.toppings && data.toppings.length > 0 ? (
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                  {data.toppings.map(
                    (t: {
                      topping_name: string
                      total_quantity: number
                      total_sales: number
                    }) => (
                      <div
                        key={t.topping_name}
                        className="flex items-center justify-between rounded-lg border border-border bg-background p-3"
                      >
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            {t.topping_name}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {t.total_quantity} uds
                          </p>
                        </div>
                        <p className="text-sm font-bold text-foreground">
                          {formatCOP(Number(t.total_sales))}
                        </p>
                      </div>
                    )
                  )}
                </div>
              ) : (
                <p className="py-8 text-center text-sm text-muted-foreground">
                  Sin toppings vendidos en esta fecha
                </p>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
