import { sql } from "@/lib/db"
import { NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const date = searchParams.get("date") || new Date().toISOString().split("T")[0]

    // Day summary
    const summary = await sql`
      SELECT 
        COUNT(*) as total_orders,
        COALESCE(SUM(total), 0) as total_revenue,
        COALESCE(SUM(delivery_fee), 0) as total_delivery_fees,
        COALESCE(SUM(subtotal), 0) as total_subtotal,
        COUNT(CASE WHEN delivery_type = 'domicilio' THEN 1 END) as delivery_orders,
        COUNT(CASE WHEN delivery_type = 'local' THEN 1 END) as local_orders,
        COUNT(CASE WHEN status = 'entregado' THEN 1 END) as delivered_count,
        COUNT(CASE WHEN status = 'cancelado' THEN 1 END) as cancelled_count
      FROM orders
      WHERE DATE(created_at) = ${date}
    `

    // Products sold
    const productsSold = await sql`
      SELECT 
        oi.product_name,
        SUM(oi.quantity) as total_quantity,
        SUM(oi.subtotal) as total_sales
      FROM order_items oi
      JOIN orders o ON o.id = oi.order_id
      WHERE DATE(o.created_at) = ${date} AND o.status != 'cancelado'
      GROUP BY oi.product_name
      ORDER BY total_sales DESC
    `

    // Toppings sold
    const toppingsSold = await sql`
      SELECT 
        oit.topping_name,
        COUNT(*) as total_count,
        SUM(oit.price) as total_sales
      FROM order_item_toppings oit
      JOIN order_items oi ON oi.id = oit.order_item_id
      JOIN orders o ON o.id = oi.order_id
      WHERE DATE(o.created_at) = ${date} AND o.status != 'cancelado'
      GROUP BY oit.topping_name
      ORDER BY total_count DESC
    `

    // Hourly breakdown
    const hourly = await sql`
      SELECT 
        EXTRACT(HOUR FROM created_at) as hour,
        COUNT(*) as orders,
        COALESCE(SUM(total), 0) as revenue
      FROM orders
      WHERE DATE(created_at) = ${date} AND status != 'cancelado'
      GROUP BY EXTRACT(HOUR FROM created_at)
      ORDER BY hour
    `

    return NextResponse.json({
      date,
      summary: summary[0],
      productsSold,
      toppingsSold,
      hourly,
    })
  } catch (error) {
    console.error("Error fetching report:", error)
    return NextResponse.json(
      { error: "Error al generar reporte" },
      { status: 500 }
    )
  }
}
